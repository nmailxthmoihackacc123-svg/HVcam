# HSang VCam (Android prototype)

This is a small Android app that lets the user pick a video and play it in a looping preview inside the app.

## Important limitation
This prototype does **not** replace Android's system camera and other apps (TikTok, Zalo, Messenger) will not see it as a camera. A normal non-root APK cannot register itself as a system-wide virtual camera on standard Android devices.

## Build
Open this folder in Android Studio (Hedgehog or newer), allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Package: `com.huusang.vcam`
Min Android: 6.0 (API 23)
