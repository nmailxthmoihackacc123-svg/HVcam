package com.huusang.vcam;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.MediaController;
import android.graphics.Color;
import android.graphics.Typeface;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 101;
    private VideoView videoView;
    private TextView status;
    private Button playButton;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(0);
        getWindow().setStatusBarColor(Color.rgb(9,9,13));
        getWindow().setNavigationBarColor(Color.rgb(9,9,13));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(9,9,13));

        TextView title = new TextView(this);
        title.setText("HSang VCam");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Phát video lặp trong ứng dụng");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setPadding(0, dp(5), 0, dp(16));
        root.addView(subtitle);

        videoView = new VideoView(this);
        LinearLayout.LayoutParams videoParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        videoParams.bottomMargin = dp(14);
        root.addView(videoView, videoParams);

        status = new TextView(this);
        status.setText("Chưa chọn video");
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(13);
        status.setPadding(0, 0, 0, dp(12));
        root.addView(status);

        Button choose = makeButton("CHỌN VIDEO");
        choose.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("video/*");
            startActivityForResult(intent, PICK_VIDEO);
        });
        root.addView(choose, buttonParams());

        playButton = makeButton("PHÁT / TẠM DỪNG");
        playButton.setOnClickListener(v -> {
            if (videoView.getDuration() <= 0) {
                Toast.makeText(this, "Hãy chọn video trước", Toast.LENGTH_SHORT).show();
            } else if (videoView.isPlaying()) {
                videoView.pause();
            } else {
                videoView.start();
            }
        });
        root.addView(playButton, buttonParams());
        setContentView(root);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(83,62,180)));
        return b;
    }
    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52));
        p.bottomMargin = dp(9);
        return p;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) { }
                videoView.setVideoURI(uri);
                videoView.setOnPreparedListener(mp -> {
                    mp.setLooping(true);
                    videoView.start();
                    status.setText("Đang phát video · Lặp liên tục");
                });
                videoView.setOnErrorListener((mp, what, extra) -> {
                    status.setText("Không phát được video này");
                    return true;
                });
                status.setText("Đang tải video...");
            }
        }
    }
}
